import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Calendar, User, Book, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function EmprestimosPage() {
  const emprestimos = [
    {
      id: "001",
      livro: "O Senhor dos Anéis",
      usuario: "João Silva",
      dataEmprestimo: "15/01/2025",
      dataDevolucao: "29/01/2025",
      status: "ativo",
    },
    {
      id: "002",
      livro: "1984",
      usuario: "Maria Santos",
      dataEmprestimo: "10/01/2025",
      dataDevolucao: "24/01/2025",
      status: "atrasado",
    },
    {
      id: "003",
      livro: "Dom Casmurro",
      usuario: "Pedro Oliveira",
      dataEmprestimo: "08/01/2025",
      dataDevolucao: "12/01/2025",
      status: "devolvido",
    },
    {
      id: "004",
      livro: "O Pequeno Príncipe",
      usuario: "Ana Costa",
      dataEmprestimo: "18/01/2025",
      dataDevolucao: "01/02/2025",
      status: "ativo",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <Link href="/">
              <Button variant="ghost" size="sm" className="mb-2 gap-2">
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-foreground">Gerenciar Empréstimos</h1>
            <p className="text-muted-foreground">Controle todos os empréstimos ativos e histórico</p>
          </div>
          <Button className="gap-2">
            <Book className="h-4 w-4" />
            Novo Empréstimo
          </Button>
        </div>

        <div className="rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Livro</TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead>Data Empréstimo</TableHead>
                <TableHead>Data Devolução</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {emprestimos.map((emprestimo) => (
                <TableRow key={emprestimo.id}>
                  <TableCell className="font-medium">{emprestimo.id}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Book className="h-4 w-4 text-muted-foreground" />
                      {emprestimo.livro}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      {emprestimo.usuario}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      {emprestimo.dataEmprestimo}
                    </div>
                  </TableCell>
                  <TableCell>{emprestimo.dataDevolucao}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        emprestimo.status === "ativo"
                          ? "default"
                          : emprestimo.status === "atrasado"
                            ? "destructive"
                            : "secondary"
                      }
                    >
                      {emprestimo.status === "ativo"
                        ? "Ativo"
                        : emprestimo.status === "atrasado"
                          ? "Atrasado"
                          : "Devolvido"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    {emprestimo.status !== "devolvido" && (
                      <Button size="sm" variant="outline">
                        Registrar Devolução
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  )
}
