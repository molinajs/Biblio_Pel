"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Plus, Search, Edit, Trash2 } from "lucide-react"

export default function LivrosPage() {
  const [open, setOpen] = useState(false)

  const books = [
    { id: 1, titulo: "1984", autor: "George Orwell", categoria: "Ficção", ano: "1949", exemplares: 5, disponiveis: 3 },
    {
      id: 2,
      titulo: "Dom Casmurro",
      autor: "Machado de Assis",
      categoria: "Clássico",
      ano: "1899",
      exemplares: 8,
      disponiveis: 7,
    },
    {
      id: 3,
      titulo: "O Pequeno Príncipe",
      autor: "Antoine de Saint-Exupéry",
      categoria: "Infantil",
      ano: "1943",
      exemplares: 12,
      disponiveis: 10,
    },
    {
      id: 4,
      titulo: "Harry Potter",
      autor: "J.K. Rowling",
      categoria: "Fantasia",
      ano: "1997",
      exemplares: 15,
      disponiveis: 8,
    },
    {
      id: 5,
      titulo: "O Senhor dos Anéis",
      autor: "J.R.R. Tolkien",
      categoria: "Fantasia",
      ano: "1954",
      exemplares: 10,
      disponiveis: 6,
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Gerenciar Livros</h1>
          <p className="text-muted-foreground">Controle todo o acervo da biblioteca</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Adicionar Livro
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Adicionar Novo Livro</DialogTitle>
              <DialogDescription>Preencha as informações do livro para adicionar ao acervo</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="titulo">Título</Label>
                <Input id="titulo" placeholder="Digite o título do livro" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="autor">Autor</Label>
                <Input id="autor" placeholder="Digite o nome do autor" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="categoria">Categoria</Label>
                  <Input id="categoria" placeholder="Ex: Ficção" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="ano">Ano</Label>
                  <Input id="ano" placeholder="Ex: 2024" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="exemplares">Número de Exemplares</Label>
                <Input id="exemplares" type="number" placeholder="0" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={() => setOpen(false)}>Adicionar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="p-6">
        <div className="mb-4 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Buscar por título, autor ou categoria..." className="pl-9" />
          </div>
        </div>

        <div className="rounded-md border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Título</TableHead>
                <TableHead>Autor</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Ano</TableHead>
                <TableHead>Exemplares</TableHead>
                <TableHead>Disponíveis</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {books.map((book) => (
                <TableRow key={book.id}>
                  <TableCell className="font-medium">{book.titulo}</TableCell>
                  <TableCell>{book.autor}</TableCell>
                  <TableCell>{book.categoria}</TableCell>
                  <TableCell>{book.ano}</TableCell>
                  <TableCell>{book.exemplares}</TableCell>
                  <TableCell>
                    <span className={book.disponiveis > 0 ? "text-green-600" : "text-destructive"}>
                      {book.disponiveis}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  )
}
